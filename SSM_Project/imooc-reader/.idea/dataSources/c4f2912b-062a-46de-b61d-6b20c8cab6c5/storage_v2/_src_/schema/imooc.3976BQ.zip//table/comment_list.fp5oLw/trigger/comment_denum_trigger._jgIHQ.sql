create definer = root@localhost trigger comment_denum_trigger
    after delete
    on comment_list
    for each row
begin
    update article_list set comment = comment - 1
    where article_list.contentType = old.contenttype and article_list.id = old.contentid;
end;

