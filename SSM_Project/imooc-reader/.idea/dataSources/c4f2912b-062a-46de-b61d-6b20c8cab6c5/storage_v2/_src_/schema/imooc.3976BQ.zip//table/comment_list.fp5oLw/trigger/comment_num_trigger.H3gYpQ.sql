create definer = root@localhost trigger comment_num_trigger
    after insert
    on comment_list
    for each row
begin
        update article_list set comment = comment + 1
        where article_list.contentType = new.contenttype and article_list.id = new.contentid;
    end;

